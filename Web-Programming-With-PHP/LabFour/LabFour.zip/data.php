<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

$invitations = array(
    "Иван Иванов" => array("открито изложение." => "Бъдете 10 минути преди откриването!"),
    "Петър Петров" => array("бал на випускниците." => "Не забравяйте да донесете подарък :-)"),
    "Симеон Семов" => array("ден на отворените врати." => "Моля, потвърдете Вашето участие по телефона!")
);

?>